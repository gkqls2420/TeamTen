
public class CardManager {
	private Card card;
	
	public CardManager(Mediator mediator) {
	}
	
	//converse data String into card
	public Card converse(String[] data) {
		return this.card;
	}
}
