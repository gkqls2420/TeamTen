
public abstract class Data {

}
