public class VolunteerManager {
	private Volunteer volunteer;
	
	public VolunteerManager(Mediator mediator) {
	}
	
	//converse data string into volunteer
	public Volunteer converse(String[] data) {
		return this.volunteer;
	}
}
